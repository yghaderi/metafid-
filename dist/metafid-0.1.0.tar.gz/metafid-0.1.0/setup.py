# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['metafid', 'metafid.ta']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.24.2,<2.0.0']

entry_points = \
{'console_scripts': ['our_command = metafid.main:run']}

setup_kwargs = {
    'name': 'metafid',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Yaghoub Ghadri',
    'author_email': 'y.ghaderi@outlook.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
